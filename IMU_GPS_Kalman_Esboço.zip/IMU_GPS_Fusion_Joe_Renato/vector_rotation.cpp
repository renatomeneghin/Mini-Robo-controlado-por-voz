#import <cmath>
#import <Eigen/Dense>

using namespace vn::math;

vec3f vector_rotation_YPR(vec3f V,vec3f YPR){
    float yaw = YPR[0];
    float pitch = YPR[1];
    float roll = YPR[2];
    
    float qx = sin(roll/2)*cos(pitch/2)*cos(yaw/2) - cos(roll/2)*sin(pitch/2)*sin(yaw/2);
    float qy = cos(roll/2)*sin(pitch/2)*cos(yaw/2) + sin(roll/2)*cos(pitch/2)*sin(yaw/2);
    float qz = cos(roll/2)*cos(pitch/2)*sin(yaw/2) - sin(roll/2)*sin(pitch/2)*cos(yaw/2);
    float qw = cos(roll/2)*cos(pitch/2)*cos(yaw/2) + sin(roll/2)*sin(pitch/2)*sin(yaw/2);
    
    Eigen::Matrix4f q(4,4);
    q << qw,-qx,-qy,-qz,
         qx,qw,-qz,-qy,
         qy,qz,qw,-qx,
         qz,-qy,qx,qw;
         
    Eigen::Matrix4f qv;
    qv <<   0   ,-V[0]  ,-V[1]  ,-V[2],
            V[0],0      ,-V[2]  ,V[1],
            V[1],V[2]   ,0      ,-V[0],
            V[2],-V[1]  ,V[0]   ,0   ;
    //Vr = q*qv*q'      
    Eigen::Matrix4f Vr;
    Vr = q*qv*q.transpose();

    vec3f = V_final;
    V_final[0] = Vr[1][0];
    V_final[1] = Vr[2][0];
    V_final[2] = Vr[3][0];
        
    return V_final;
}

vec3f vector_rotation_YPR(vec3f V,vec4f Quat){
    float qw = Quat.w;
    float qx = Quat.x;
    float qy = Quat.y;
    float qz = Quat.z;
    
    Eigen::Matrix4f q(4,4);
    q << qw,-qx,-qy,-qz,
         qx,qw,-qz,-qy,
         qy,qz,qw,-qx,
         qz,-qy,qx,qw;
         
    Eigen::Matrix4f qv;
    qv <<   0   ,-V[0]  ,-V[1]  ,-V[2],
            V[0],0      ,-V[2]  ,V[1],
            V[1],V[2]   ,0      ,-V[0],
            V[2],-V[1]  ,V[0]   ,0   ;
    //Vr = q*qv*q'      
    Eigen::Matrix4f Vr;
    Vr = q*qv*q.transpose();

    vec3f = V_final;
    V_final[0] = Vr[1][0];
    V_final[1] = Vr[2][0];
    V_final[2] = Vr[3][0];
        
    return V_final;
}