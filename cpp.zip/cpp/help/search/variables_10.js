var searchData=
[
  ['r',['r',['../structvn_1_1math_1_1vec_3_013_00_01_t_01_4.html#a9c92e99ab87305f7e403f8f8d2a6a95d',1,'vn::math::vec&lt; 3, T &gt;::r()'],['../structvn_1_1math_1_1vec_3_014_00_01_t_01_4.html#a8cdc3e7a6e3dde7c7bd8e7718bee3785',1,'vn::math::vec&lt; 4, T &gt;::r()']]],
  ['ratedivisor',['rateDivisor',['../structvn_1_1sensors_1_1_binary_output_register.html#aad4ddf1b30d2811f060275cd26e2fa8b',1,'vn::sensors::BinaryOutputRegister']]],
  ['ratetuning',['rateTuning',['../structvn_1_1sensors_1_1_velocity_compensation_control_register.html#a8b97adfa87496b63ad919bae21b9d9df',1,'vn::sensors::VelocityCompensationControlRegister']]],
  ['recalcthreshold',['recalcThreshold',['../structvn_1_1sensors_1_1_reference_vector_configuration_register.html#a9b28a81a97484eced9d772200acd2b34',1,'vn::sensors::ReferenceVectorConfigurationRegister']]]
];
