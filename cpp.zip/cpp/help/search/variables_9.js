var searchData=
[
  ['knownacceldisturbance',['knownAccelDisturbance',['../structvn_1_1protocol_1_1uart_1_1_vpe_status.html#aba4b956bed21e35bccf49fe4bd7d9e4b',1,'vn::protocol::uart::VpeStatus']]],
  ['knownmagdisturbance',['knownMagDisturbance',['../structvn_1_1protocol_1_1uart_1_1_vpe_status.html#a30171e3666acbf1e9fc143b925262006',1,'vn::protocol::uart::VpeStatus']]]
];
