var searchData=
[
  ['quaternionmagneticaccelerationandangularratesregister',['QuaternionMagneticAccelerationAndAngularRatesRegister',['../structvn_1_1sensors_1_1_quaternion_magnetic_acceleration_and_angular_rates_register.html',1,'vn::sensors']]]
];
