var searchData=
[
  ['calculatedmagnetometercalibrationregister',['CalculatedMagnetometerCalibrationRegister',['../structvn_1_1sensors_1_1_calculated_magnetometer_calibration_register.html',1,'vn::sensors']]],
  ['checksum8',['Checksum8',['../classvn_1_1data_1_1integrity_1_1_checksum8.html',1,'vn::data::integrity']]],
  ['communicationprotocolcontrolregister',['CommunicationProtocolControlRegister',['../structvn_1_1sensors_1_1_communication_protocol_control_register.html',1,'vn::sensors']]],
  ['compositedata',['CompositeData',['../classvn_1_1sensors_1_1_composite_data.html',1,'vn::sensors']]],
  ['crc16',['Crc16',['../classvn_1_1data_1_1integrity_1_1_crc16.html',1,'vn::data::integrity']]],
  ['criticalsection',['CriticalSection',['../classvn_1_1xplat_1_1_critical_section.html',1,'vn::xplat']]]
];
