var searchData=
[
  ['unknown',['UNKNOWN',['../classvn_1_1xplat_1_1_signal.html#ad02f356a444decae6c3a894a9694173dab9511a1a04f043b9f8f30401baa69a8c',1,'vn::xplat::Signal']]]
];
