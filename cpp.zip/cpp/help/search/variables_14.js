var searchData=
[
  ['velatt',['velAtt',['../structvn_1_1sensors_1_1_ins_advanced_configuration_register.html#afc59fad9ad5859c59be8867621e1b979',1,'vn::sensors::InsAdvancedConfigurationRegister']]],
  ['velbias',['velBias',['../structvn_1_1sensors_1_1_ins_advanced_configuration_register.html#af118075d27627151dbaebe5d91714a89',1,'vn::sensors::InsAdvancedConfigurationRegister']]],
  ['velcount',['velCount',['../structvn_1_1sensors_1_1_ins_advanced_configuration_register.html#a7eeda340ad52b700dd67847cb285b8a3',1,'vn::sensors::InsAdvancedConfigurationRegister']]],
  ['velinit',['velInit',['../structvn_1_1sensors_1_1_ins_advanced_configuration_register.html#a51aef9bcb3cb65c218961b7af2d17cd0',1,'vn::sensors::InsAdvancedConfigurationRegister']]],
  ['velocity',['velocity',['../structvn_1_1sensors_1_1_gps_solution_ecef_register.html#ae480517630b8d0dfaff99b9e95d009ca',1,'vn::sensors::GpsSolutionEcefRegister::velocity()'],['../structvn_1_1sensors_1_1_ins_solution_ecef_register.html#aa68f109a7738a318b735c2c95e95a349',1,'vn::sensors::InsSolutionEcefRegister::velocity()'],['../structvn_1_1sensors_1_1_ins_state_lla_register.html#a77dc31b5725f22464de5207c62f96a96',1,'vn::sensors::InsStateLlaRegister::velocity()'],['../structvn_1_1sensors_1_1_ins_state_ecef_register.html#ab9df3f31ec10311af9fae903920ea4eb',1,'vn::sensors::InsStateEcefRegister::velocity()']]],
  ['velocitytuning',['velocityTuning',['../structvn_1_1sensors_1_1_velocity_compensation_control_register.html#abe409a6c2825f903c358ade6336094cb',1,'vn::sensors::VelocityCompensationControlRegister']]],
  ['veluncertainty',['velUncertainty',['../structvn_1_1sensors_1_1_ins_solution_lla_register.html#a1967e844a2b1d8b6b1a3da30bf445735',1,'vn::sensors::InsSolutionLlaRegister::velUncertainty()'],['../structvn_1_1sensors_1_1_ins_solution_ecef_register.html#a3d838357fbf03298933cbb4c59bf0ea3',1,'vn::sensors::InsSolutionEcefRegister::velUncertainty()']]]
];
