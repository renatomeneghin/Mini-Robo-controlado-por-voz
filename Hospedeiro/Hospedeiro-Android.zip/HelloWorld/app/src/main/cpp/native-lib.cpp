#include <jni.h>
#include <iostream>
#include <string>
#include <thread>
#include "include/clockcalendar.h"
#include "include/Lista.h"
#include <sstream>
#include <fstream>

using namespace std;

List dados;

void lerArquivo(const char *);
string listarUm(Dados);

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_helloworld_MainActivity_TextoPadrao(
        JNIEnv* env,
        jobject /* this */) {
    std::stringstream Tempo;
    try{bool lista = strcmp(dados.readFirst().Operacao,"");}
    catch (const char *s){
        lerArquivo("/storage/41ED-16F2/Documents/Android Development/Dados_Sinteticos.txt");
    }
    int hora, minuto, segundo, pm;
    ClockCalendar cc1 = dados.readLast().Data_Hora;

    cc1.subtract(dados.readFirst().Data_Hora);
    cc1.readClock(&hora,&segundo,&minuto,&pm);

    Tempo << "Tempo de funcionamento: "
    << std::setfill('0') << std::setw(2) << hora
    << ":" << std::setfill('0') << std::setw(2) << minuto
    << ":" << std::setfill('0') << std::setw(2) << segundo;

    return env->NewStringUTF(Tempo.str().c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_helloworld_MainActivity_TextoRegistros(
        JNIEnv* env,
        jobject /* this */) {
    std::stringstream Registros;
    Dados dado;
    try{bool lista = strcmp(dados.readFirst().Operacao,"");}
    catch (const char *s){
        lerArquivo("/storage/41ED-16F2/Documents/Android Development/Dados_Sinteticos.txt");
    }
    dado = dados.removeFirst();
    while(strcmp(dado.Operacao,"")){
        Registros << listarUm(dado);
        dado = dados.removeFirst();
    }

    return env->NewStringUTF(Registros.str().c_str());
}

string listarUm(Dados data){
    int mes, dia, ano, hora, minuto, segundo, pm, is_meiodia;
    data.Data_Hora.readCalendar(&mes, &dia, &ano);
    data.Data_Hora.readClock(&hora, &segundo, &minuto, &pm);
    is_meiodia = (pm)? 1 : 0;
    char meiodia[2][3] = {"AM", "PM"};
    stringstream texto;

    texto     << "Operação Executada: " << data.Operacao << std::endl
              << "Data: " << std::setfill('0') << std::setw(2) << dia
              << "/" << std::setfill('0') << std::setw(2) << mes << "/" << ano
              << "\t Hora: " << std::setfill('0') << std::setw(2) << hora << ":"
              << std::setfill('0') << std::setw(2) << minuto << ":"
              << std::setfill('0') << std::setw(2) << segundo << " "
              << meiodia[is_meiodia] << std::endl << std::endl;

    return texto.str();
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_helloworld_MainActivity_inicializacao(JNIEnv *env, jobject thiz) {
    try{bool lista = strcmp(dados.readFirst().Operacao,"");}
    catch (const char *s){
        lerArquivo("/storage/41ED-16F2/Documents/Android Development/Dados_Sinteticos.txt");
    }
}

void lerArquivo(const char *s){
    ifstream leitura(s);
    string str;
    string data[8];
    if (!leitura.is_open()){
        throw "Erro na Abertura do arquivo";
    }
    while(!leitura.eof()){
        leitura >> str;
        stringstream ss(str);

        for(int i = 0; getline(ss,data[i],';');i++);
        const char* op = data[0].c_str();
        ClockCalendar tempo(stoi(data[2]),stoi(data[1]),stoi(data[3]),stoi(data[4]),stoi(data[5]),stoi(data[6]),data[7].compare("AM"));
        Dados novo_item(op,tempo);
        dados.insertAfterLast(novo_item);
    }
    leitura.close();
}
